import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';


function app2() {
  return (
    <div>app2</div>
  )
}

export default app2